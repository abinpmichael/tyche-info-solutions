<div class="container-fluid">
    <!-- Check if the success message exists in the session -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php
            // Display the success message
            echo $_SESSION['success'];
            // Unset the session message so it doesn't show again
            unset($_SESSION['success']);
            ?>
        </div>
    <?php endif; ?>
<h1>Brands</h1>
<p align="right"><a href="product/create"><button type="button" class="btn btn-info m-1">Add New Brand</button></a></p>
<div class="table-responsive">
    

  <table class="table table-vcenter">
    <thead>
         
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Description</th>
        <th>Status</th>
        
        <th class="w-1">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($product as $products): ?>
      <tr>
        <td><?= $products['p_id'] ?></td>
        <td >
         <?= $products['p_name'] ?>
        </td>
        <td ><?= $products['p_desc'] ?></td>
        <td >
          <?= $products['p_status'] ? 'Active' : 'Inactive' ?>
        </td>
        <td>
          <a href="<?= base_url('product/edit/' . $products['p_id']) ?>"><i style="font-size: 24px;" class="ti ti-edit"></i></a>|
           <a href="<?= base_url('product/delete/'.$products['p_id']) ?>"><i style="font-size: 24px;" class="ti ti-trash-x"></i></a>
        
        </td>

      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>